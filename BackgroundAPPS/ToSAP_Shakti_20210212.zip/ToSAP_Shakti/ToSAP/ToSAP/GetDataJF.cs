﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.IO;
using MySql.Data.MySqlClient;
using System.Diagnostics;
using System.Security.Permissions;
using System.Security.Principal;
using System.Runtime.InteropServices;

namespace ToSAP
{
    class GetDataJF
    {

        TATAContainer db = new TATAContainer();

        public GetDataJF(DateTime CorrectedDate)
        {

        }


    }
}
